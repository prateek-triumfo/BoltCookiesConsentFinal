<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Domain;
use App\Models\BannerSetting;
use Illuminate\Http\Request;

class BannerSettingController extends Controller
{
    public function edit(Domain $domain)
    {
        $bannerSetting = $domain->bannerSetting ?? new BannerSetting();
        return view('admin.banner-settings.edit', compact('domain', 'bannerSetting'));
    }

    public function update(Request $request, Domain $domain)
    {
        $validated = $request->validate([
            'banner_title' => 'required|string|max:255',
            'banner_description' => 'required|string',
            'accept_button_text' => 'required|string|max:50',
            'reject_button_text' => 'required|string|max:50',
            'primary_color' => 'required|string|max:7',
            'accept_button_color' => 'required|string|max:7',
            'reject_button_color' => 'required|string|max:7',
            'font_family' => 'required|string|max:50',
            'font_size' => 'required|integer|min:10|max:24',
            'show_categories' => 'boolean',
            'show_reject_all' => 'boolean',
        ]);

        $bannerSetting = $domain->bannerSetting ?? new BannerSetting();
        $bannerSetting->fill($validated);
        
        // Handle boolean fields
        $bannerSetting->show_categories = $request->has('show_categories');
        $bannerSetting->show_reject_all = $request->has('show_reject_all');
        
        // Associate with domain if new
        if (!$bannerSetting->exists) {
            $bannerSetting->domain_id = $domain->id;
        }
        
        $bannerSetting->save();

        return redirect()
            ->route('admin.banner.edit', $domain)
            ->with('success', 'Banner settings updated successfully.');
    }

    public function preview(Domain $domain)
    {
        return view('admin.banner-settings.preview', compact('domain'));
    }
}
