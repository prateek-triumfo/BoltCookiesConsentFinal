<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BannerSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'banner_title',
        'banner_description',
        'accept_button_text',
        'reject_button_text',
        'primary_color',
        'accept_button_color',
        'reject_button_color',
        'font_family',
        'font_size',
        'show_categories',
        'show_reject_all',
    ];

    protected $casts = [
        'show_categories' => 'boolean',
        'show_reject_all' => 'boolean',
        'font_size' => 'integer',
    ];

    public function domain()
    {
        return $this->belongsTo(Domain::class);
    }

    public static function getDefaultSettings($domainId)
    {
        $defaultSettings = [
            'domain_id' => $domainId,
            'banner_title' => 'Cookie Consent',
            'banner_description' => 'We use cookies to enhance your browsing experience and analyze our traffic.',
            'accept_button_text' => 'Accept All',
            'reject_button_text' => 'Reject All',
            'primary_color' => '#2196F3',
            'accept_button_color' => '#4CAF50',
            'reject_button_color' => '#f44336',
            'font_family' => 'Arial, sans-serif',
            'font_size' => 14,
            'show_categories' => true,
            'show_reject_all' => true
        ];

        // Try to get existing settings for this domain
        $settings = self::where('domain_id', $domainId)->first();

        // If no settings exist, create new ones
        if (!$settings) {
            $settings = self::create($defaultSettings);
        }

        return $settings;
    }
}
