<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('banner_settings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('domain_id')->constrained()->onDelete('cascade');
            $table->string('banner_title')->default('Cookie Consent');
            $table->text('banner_description')->default('We use cookies to enhance your browsing experience and analyze our traffic.');
            $table->string('accept_all_text')->default('Accept All');
            $table->string('reject_all_text')->default('Reject All');
            $table->string('manage_settings_text')->default('Manage Settings');
            $table->string('save_preferences_text')->default('Save Preferences');
            $table->string('cancel_text')->default('Cancel');
            $table->string('primary_color')->default('#2196F3');
            $table->string('accept_color')->default('#4CAF50');
            $table->string('reject_color')->default('#f44336');
            $table->string('background_color')->default('#ffffff');
            $table->string('text_color')->default('#000000');
            $table->string('font_family')->default('Arial, sans-serif');
            $table->integer('font_size')->default(14);
            $table->boolean('show_manage_button')->default(true);
            $table->string('manage_button_position')->default('bottom-right');
            $table->boolean('show_necessary_cookies')->default(true);
            $table->boolean('show_statistics_cookies')->default(true);
            $table->boolean('show_marketing_cookies')->default(true);
            $table->boolean('show_preferences_cookies')->default(true);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('banner_settings');
    }
}; 