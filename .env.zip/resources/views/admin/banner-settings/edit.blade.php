<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Edit Banner Settings for') }} {{ $domain->name }}
            </h2>
            <a href="{{ route('admin.domains.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                Back to Domains
            </a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <span class="block sm:inline">{{ session('success') }}</span>
                        </div>
                    @endif

                    <form action="{{ route('admin.banner.update', $domain) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <!-- Banner Title -->
                        <div class="mb-4">
                            <label for="banner_title" class="block text-sm font-medium text-gray-700">Banner Title</label>
                            <input type="text" name="banner_title" id="banner_title" value="{{ old('banner_title', $bannerSetting->banner_title ?? '') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            @error('banner_title')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Banner Description -->
                        <div class="mb-4">
                            <label for="banner_description" class="block text-sm font-medium text-gray-700">Banner Description</label>
                            <textarea name="banner_description" id="banner_description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">{{ old('banner_description', $bannerSetting->banner_description ?? '') }}</textarea>
                            @error('banner_description')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Button Text -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="accept_button_text" class="block text-sm font-medium text-gray-700">Accept Button Text</label>
                                <input type="text" name="accept_button_text" id="accept_button_text" value="{{ old('accept_button_text', $bannerSetting->accept_button_text ?? 'Accept All') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="reject_button_text" class="block text-sm font-medium text-gray-700">Reject Button Text</label>
                                <input type="text" name="reject_button_text" id="reject_button_text" value="{{ old('reject_button_text', $bannerSetting->reject_button_text ?? 'Reject All') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>

                        <!-- Colors -->
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <label for="primary_color" class="block text-sm font-medium text-gray-700">Primary Color</label>
                                <input type="color" name="primary_color" id="primary_color" value="{{ old('primary_color', $bannerSetting->primary_color ?? '#4F46E5') }}" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="accept_button_color" class="block text-sm font-medium text-gray-700">Accept Button Color</label>
                                <input type="color" name="accept_button_color" id="accept_button_color" value="{{ old('accept_button_color', $bannerSetting->accept_button_color ?? '#10B981') }}" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="reject_button_color" class="block text-sm font-medium text-gray-700">Reject Button Color</label>
                                <input type="color" name="reject_button_color" id="reject_button_color" value="{{ old('reject_button_color', $bannerSetting->reject_button_color ?? '#EF4444') }}" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                        </div>

                        <!-- Font Settings -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="font_family" class="block text-sm font-medium text-gray-700">Font Family</label>
                                <select name="font_family" id="font_family" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                    @foreach(['Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana'] as $font)
                                        <option value="{{ $font }}" {{ (old('font_family', $bannerSetting->font_family ?? '') == $font) ? 'selected' : '' }}>{{ $font }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div>
                                <label for="font_size" class="block text-sm font-medium text-gray-700">Font Size (px)</label>
                                <input type="number" name="font_size" id="font_size" value="{{ old('font_size', $bannerSetting->font_size ?? 14) }}" min="10" max="24" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>

                        <!-- Display Options -->
                        <div class="space-y-4 mb-6">
                            <div class="flex items-center">
                                <input type="checkbox" name="show_categories" id="show_categories" value="1" {{ old('show_categories', $bannerSetting->show_categories ?? true) ? 'checked' : '' }} class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="show_categories" class="ml-2 block text-sm text-gray-900">Show Cookie Categories</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" name="show_reject_all" id="show_reject_all" value="1" {{ old('show_reject_all', $bannerSetting->show_reject_all ?? true) ? 'checked' : '' }} class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="show_reject_all" class="ml-2 block text-sm text-gray-900">Show Reject All Button</label>
                            </div>
                        </div>

                        <div class="flex justify-end space-x-3">
                            <a href="{{ route('admin.domains.index') }}" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                                Cancel
                            </a>
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                                Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 