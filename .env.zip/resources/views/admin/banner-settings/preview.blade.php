@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Banner Preview for {{ $domain->name }}</h1>
                <div>
                    <a href="{{ route('admin.banner.edit', $domain) }}" class="btn btn-primary btn-sm me-2">Back to Settings</a>
                    <a href="{{ route('admin.dashboard') }}" class="btn btn-secondary btn-sm">Back to Dashboard</a>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="preview-container">
                        <!-- Main Banner Preview -->
                        <div class="banner-preview mb-4">
                            <h4 class="mb-3">Main Banner</h4>
                            <div class="banner" style="
                                background-color: {{ $bannerSetting->background_color }};
                                color: {{ $bannerSetting->text_color }};
                                padding: 20px;
                                border-radius: 8px;
                                font-family: {{ $bannerSetting->font_family }};
                                font-size: {{ $bannerSetting->font_size }}px;
                            ">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h5 style="color: {{ $bannerSetting->text_color }};">{{ $bannerSetting->banner_title }}</h5>
                                        <p class="mb-0" style="color: {{ $bannerSetting->text_color }};">{{ $bannerSetting->banner_description }}</p>
                                    </div>
                                    <div class="d-flex gap-2">
                                        <button class="btn" style="
                                            background-color: {{ $bannerSetting->accept_color }};
                                            color: white;
                                        ">{{ $bannerSetting->accept_all_text }}</button>
                                        <button class="btn" style="
                                            background-color: {{ $bannerSetting->reject_color }};
                                            color: white;
                                        ">{{ $bannerSetting->reject_all_text }}</button>
                                        @if($bannerSetting->show_manage_button)
                                        <button class="btn" style="
                                            background-color: {{ $bannerSetting->primary_color }};
                                            color: white;
                                        ">{{ $bannerSetting->manage_settings_text }}</button>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Settings Modal Preview -->
                        <div class="modal-preview">
                            <h4 class="mb-3">Settings Modal</h4>
                            <div class="modal-content" style="
                                background-color: {{ $bannerSetting->background_color }};
                                color: {{ $bannerSetting->text_color }};
                                padding: 20px;
                                border-radius: 8px;
                                font-family: {{ $bannerSetting->font_family }};
                                font-size: {{ $bannerSetting->font_size }}px;
                            ">
                                <h5 style="color: {{ $bannerSetting->text_color }};">Cookie Settings</h5>
                                
                                <!-- Cookie Categories -->
                                <div class="cookie-categories">
                                    @if($bannerSetting->show_necessary_cookies)
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" checked disabled>
                                        <label class="form-check-label" style="color: {{ $bannerSetting->text_color }};">Necessary Cookies</label>
                                    </div>
                                    @endif

                                    @if($bannerSetting->show_statistics_cookies)
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox">
                                        <label class="form-check-label" style="color: {{ $bannerSetting->text_color }};">Statistics Cookies</label>
                                    </div>
                                    @endif

                                    @if($bannerSetting->show_marketing_cookies)
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox">
                                        <label class="form-check-label" style="color: {{ $bannerSetting->text_color }};">Marketing Cookies</label>
                                    </div>
                                    @endif

                                    @if($bannerSetting->show_preferences_cookies)
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox">
                                        <label class="form-check-label" style="color: {{ $bannerSetting->text_color }};">Preferences Cookies</label>
                                    </div>
                                    @endif
                                </div>

                                <!-- Modal Buttons -->
                                <div class="d-flex justify-content-end gap-2 mt-4">
                                    <button class="btn" style="
                                        background-color: {{ $bannerSetting->primary_color }};
                                        color: white;
                                    ">{{ $bannerSetting->save_preferences_text }}</button>
                                    <button class="btn" style="
                                        background-color: #6c757d;
                                        color: white;
                                    ">{{ $bannerSetting->cancel_text }}</button>
                                </div>
                            </div>
                        </div>

                        <!-- Manage Settings Button Preview -->
                        @if($bannerSetting->show_manage_button)
                        <div class="manage-button-preview mt-4">
                            <h4 class="mb-3">Manage Settings Button</h4>
                            <div class="position-relative" style="height: 200px; border: 1px dashed #ccc;">
                                <button class="btn position-absolute" style="
                                    background-color: {{ $bannerSetting->primary_color }};
                                    color: white;
                                    {{ $bannerSetting->manage_button_position === 'bottom-right' ? 'bottom: 20px; right: 20px;' : '' }}
                                    {{ $bannerSetting->manage_button_position === 'bottom-left' ? 'bottom: 20px; left: 20px;' : '' }}
                                    {{ $bannerSetting->manage_button_position === 'top-right' ? 'top: 20px; right: 20px;' : '' }}
                                    {{ $bannerSetting->manage_button_position === 'top-left' ? 'top: 20px; left: 20px;' : '' }}
                                ">{{ $bannerSetting->manage_settings_text }}</button>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 