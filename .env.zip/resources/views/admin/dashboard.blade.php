@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h1 class="mb-4">Admin Dashboard</h1>

            <div class="row">
                <!-- Domains and Banner Settings -->
                <div class="col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Domains & Banner Settings</h5>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Domain</th>
                                            <th>Description</th>
                                            <th>Banner Settings</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($domains as $domain)
                                        <tr>
                                            <td>{{ $domain->name }}</td>
                                            <td>{{ $domain->description }}</td>
                                            <td>
                                                @if($domain->bannerSetting)
                                                    <span class="badge bg-success">Configured</span>
                                                @else
                                                    <span class="badge bg-warning">Default Settings</span>
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{ route('admin.banner.edit', $domain) }}" class="btn btn-primary btn-sm">Manage Banner</a>
                                                <a href="{{ route('admin.domains.edit', $domain) }}" class="btn btn-secondary btn-sm">Edit Domain</a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Consent Categories Card -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Consent Categories</h5>
                            <p class="card-text">Manage consent categories and their settings.</p>
                            <a href="{{ route('admin.categories.index') }}" class="btn btn-primary">Manage Categories</a>
                        </div>
                    </div>
                </div>

                <!-- Consent Logs Card -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Consent Logs</h5>
                            <p class="card-text">View and export user consent logs.</p>
                            <a href="{{ route('admin.consent.logs.index') }}" class="btn btn-primary">View Logs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 