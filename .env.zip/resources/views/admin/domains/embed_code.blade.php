@extends('layouts.admin')

@section('content')
    <h1>Embed Code</h1>
    <pre>{{ $embedCode }}</pre>
@endsection
