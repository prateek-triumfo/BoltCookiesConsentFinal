<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Domains Section -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Domains</h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.consent.logs.index', ['domain_id' => $domain->id])); ?>" 
                               class="list-group-item list-group-item-action <?php echo e(request('domain_id') == $domain->id ? 'active' : ''); ?>">
                                <?php echo e($domain->name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Consent Logs Section -->
        <div class="col-md-8">
            <?php if($selectedDomain): ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Consent Logs for <?php echo e($selectedDomain->name); ?></h5>
                        <a href="<?php echo e(route('admin.consent.logs.export')); ?>" class="btn btn-sm btn-success">Export CSV</a>
                    </div>

                    <div class="card-body">
                        <?php if($logs && $logs->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Cookie ID</th>
                                            <th>IP Address</th>
                                            <th>Consented At</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($log->id); ?></td>
                                                <td><code><?php echo e(Str::limit($log->cookie_id, 10)); ?></code></td>
                                                <td><?php echo e($log->ip_address); ?></td>
                                                <td><?php echo e($log->consented_at->format('Y-m-d H:i:s')); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.consent.logs.show', $log)); ?>" 
                                                       class="btn btn-sm btn-outline-primary">View Details</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <div class="d-flex justify-content-center mt-4">
                                    <?php echo e($logs->links()); ?>

                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <p class="text-muted mb-0">No consent logs found for this domain.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body text-center py-5">
                        <h5 class="text-muted mb-0">Select a domain to view its consent logs</h5>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/admin/consent/logs/index.blade.php ENDPATH**/ ?>