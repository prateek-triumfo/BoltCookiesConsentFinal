<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Consent Log Details</span>
                        <a href="<?php echo e(route('admin.consent.logs.index')); ?>" class="btn btn-sm btn-outline-secondary">Back to Logs</a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="mb-4">
                        <h5>Basic Information</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr>
                                    <th style="width: 30%">ID</th>
                                    <td><?php echo e($log->id); ?></td>
                                </tr>
                                <tr>
                                    <th>Cookie ID</th>
                                    <td><code><?php echo e($log->cookie_id); ?></code></td>
                                </tr>
                                <tr>
                                    <th>IP Address</th>
                                    <td><?php echo e($log->ip_address); ?></td>
                                </tr>
                                <tr>
                                    <th>Device Type</th>
                                    <td>
                                        <?php if($log->device_type): ?>
                                            <span class="badge bg-info"><?php echo e(ucfirst($log->device_type)); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Not detected</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Language</th>
                                    <td>
                                        <?php if($log->language): ?>
                                            <code><?php echo e($log->language); ?></code>
                                        <?php else: ?>
                                            <span class="text-muted">Not detected</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Consented At</th>
                                    <td><?php echo e($log->consented_at->format('Y-m-d H:i:s')); ?></td>
                                </tr>
                                <tr>
                                    <th>Created At</th>
                                    <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                                </tr>
                                <tr>
                                    <th>Updated At</th>
                                    <td><?php echo e($log->updated_at->format('Y-m-d H:i:s')); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h5>User Agent</h5>
                        <div class="p-3 bg-light rounded">
                            <code class="text-break"><?php echo e($log->user_agent); ?></code>
                        </div>
                    </div>

                    <div>
                        <h5>Consent Preferences</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $log->consent_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($categories[$categoryId] ?? "Category {$categoryId}"); ?></td>
                                            <td>
                                                <?php if($status): ?>
                                                    <span class="badge bg-success">Accepted</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Rejected</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/admin/consent/logs/show.blade.php ENDPATH**/ ?>