<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Edit Banner Settings for')); ?> <?php echo e($domain->name); ?>

            </h2>
            <a href="<?php echo e(route('admin.domains.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                Back to Domains
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php if(session('success')): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.banner.update', $domain)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Banner Title -->
                        <div class="mb-4">
                            <label for="banner_title" class="block text-sm font-medium text-gray-700">Banner Title</label>
                            <input type="text" name="banner_title" id="banner_title" value="<?php echo e(old('banner_title', $bannerSetting->banner_title ?? '')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <?php $__errorArgs = ['banner_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Banner Description -->
                        <div class="mb-4">
                            <label for="banner_description" class="block text-sm font-medium text-gray-700">Banner Description</label>
                            <textarea name="banner_description" id="banner_description" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"><?php echo e(old('banner_description', $bannerSetting->banner_description ?? '')); ?></textarea>
                            <?php $__errorArgs = ['banner_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Button Text -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="accept_button_text" class="block text-sm font-medium text-gray-700">Accept Button Text</label>
                                <input type="text" name="accept_button_text" id="accept_button_text" value="<?php echo e(old('accept_button_text', $bannerSetting->accept_button_text ?? 'Accept All')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="reject_button_text" class="block text-sm font-medium text-gray-700">Reject Button Text</label>
                                <input type="text" name="reject_button_text" id="reject_button_text" value="<?php echo e(old('reject_button_text', $bannerSetting->reject_button_text ?? 'Reject All')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>

                        <!-- Colors -->
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <label for="primary_color" class="block text-sm font-medium text-gray-700">Primary Color</label>
                                <input type="color" name="primary_color" id="primary_color" value="<?php echo e(old('primary_color', $bannerSetting->primary_color ?? '#4F46E5')); ?>" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="accept_button_color" class="block text-sm font-medium text-gray-700">Accept Button Color</label>
                                <input type="color" name="accept_button_color" id="accept_button_color" value="<?php echo e(old('accept_button_color', $bannerSetting->accept_button_color ?? '#10B981')); ?>" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="reject_button_color" class="block text-sm font-medium text-gray-700">Reject Button Color</label>
                                <input type="color" name="reject_button_color" id="reject_button_color" value="<?php echo e(old('reject_button_color', $bannerSetting->reject_button_color ?? '#EF4444')); ?>" class="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                        </div>

                        <!-- Font Settings -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="font_family" class="block text-sm font-medium text-gray-700">Font Family</label>
                                <select name="font_family" id="font_family" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                    <?php $__currentLoopData = ['Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($font); ?>" <?php echo e((old('font_family', $bannerSetting->font_family ?? '') == $font) ? 'selected' : ''); ?>><?php echo e($font); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="font_size" class="block text-sm font-medium text-gray-700">Font Size (px)</label>
                                <input type="number" name="font_size" id="font_size" value="<?php echo e(old('font_size', $bannerSetting->font_size ?? 14)); ?>" min="10" max="24" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            </div>
                        </div>

                        <!-- Display Options -->
                        <div class="space-y-4 mb-6">
                            <div class="flex items-center">
                                <input type="checkbox" name="show_categories" id="show_categories" value="1" <?php echo e(old('show_categories', $bannerSetting->show_categories ?? true) ? 'checked' : ''); ?> class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="show_categories" class="ml-2 block text-sm text-gray-900">Show Cookie Categories</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" name="show_reject_all" id="show_reject_all" value="1" <?php echo e(old('show_reject_all', $bannerSetting->show_reject_all ?? true) ? 'checked' : ''); ?> class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="show_reject_all" class="ml-2 block text-sm text-gray-900">Show Reject All Button</label>
                            </div>
                        </div>

                        <div class="flex justify-end space-x-3">
                            <a href="<?php echo e(route('admin.domains.index')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                                Cancel
                            </a>
                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                                Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\Arun\Laravel\BoltConsent\resources\views/admin/banner-settings/edit.blade.php ENDPATH**/ ?>